'''
El projecte en que estàs treballant requereix que l’usuari introdueixi un valor 
natural entre 10 i 5000 (inclosos) i, en cas que no ho faci, li torni a demanar 
que introdueixi el nombre (fins a un màxim de 3 cops). Implementa aquesta funció 
de validació.
'''
import functions

def main():
    
    x = functions.vlt_num()
    print(x)
    
if __name__ == '__main__':
    main()
